﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimeChecker
{
    public class PercentMsg
    {
        public int percent;
        public bool alerted = false;
        public string msg;
    }
}
